from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('add_recuerdo/', views.add_recuerdo, name='add_recuerdo'),
    path('edit_recuerdo/<int:pk>/', views.edit_recuerdo, name='edit_recuerdo'),  # Ruta para editar recuerdos
    path('delete_recuerdo/<int:pk>/', views.delete_recuerdo, name='delete_recuerdo'),  # Ruta para eliminar recuerdos
]