from django.test import TestCase
from django.urls import reverse
from .models import Recuerdo, Perfil
from django.contrib.auth.models import User

class RecuerdoModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.recuerdo = Recuerdo.objects.create(titulo='Mi primer recuerdo', descripcion='Descripción del recuerdo', autor=self.user)

    def test_recuerdo_creation(self):
        self.assertEqual(self.recuerdo.titulo, 'Mi primer recuerdo')
        self.assertEqual(self.recuerdo.descripcion, 'Descripción del recuerdo')
        self.assertEqual(self.recuerdo.autor.username, 'testuser')

class PerfilModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.perfil = Perfil.objects.create(usuario=self.user, biografia='Esta es mi biografía')

    def test_perfil_creation(self):
        self.assertEqual(self.perfil.usuario.username, 'testuser')
        self.assertEqual(self.perfil.biografia, 'Esta es mi biografía')

class RecuerdoViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.client.login(username='testuser', password='testpass')

    def test_recuerdo_list_view(self):
        response = self.client.get(reverse('recuerdo_list'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'home.html')

    def test_recuerdo_create_view(self):
        response = self.client.post(reverse('recuerdo_create'), {'titulo': 'Nuevo recuerdo', 'descripcion': 'Descripción del nuevo recuerdo'})
        self.assertEqual(response.status_code, 302)  # Redirige después de crear

    def test_recuerdo_delete_view(self):
        recuerdo = Recuerdo.objects.create(titulo='Recuerdo a eliminar', descripcion='Descripción', autor=self.user)
        response = self.client.post(reverse('recuerdo_delete', args=[recuerdo.id]))
        self.assertEqual(response.status_code, 302)  # Redirige después de eliminar

class UserRegistrationTest(TestCase):
    def test_user_registration(self):
        response = self.client.post(reverse('register'), {'username': 'newuser', 'password1': 'testpass123', 'password2': 'testpass123'})
        self.assertEqual(response.status_code, 302)  # Redirige después de registrarse
        self.assertTrue(User.objects.filter(username='newuser').exists())