from django.db import models
from django.contrib.auth.models import User


class Perfil(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)
    biografia = models.TextField(blank=True, null=True)
    fecha_nacimiento = models.DateField(blank=True, null=True)
    foto_perfil = models.ImageField(upload_to='perfiles/', blank=True, null=True)

    def __str__(self):
        return self.usuario.username

class ImagenInicio(models.Model):
    titulo = models.CharField(max_length=100)
    imagen = models.ImageField(upload_to='inicio/')
    descripcion = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.titulo

class Recuerdo(models.Model):
    encabezado = models.CharField(max_length=100)
    imagen = models.ImageField(upload_to='recuerdos/', blank=True, null=True)
    fecha_creacion = models.DateTimeField()
    autor = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.encabezado