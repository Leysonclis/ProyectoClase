from django.apps import AppConfig

class MemoryAlbumConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'memory_album'