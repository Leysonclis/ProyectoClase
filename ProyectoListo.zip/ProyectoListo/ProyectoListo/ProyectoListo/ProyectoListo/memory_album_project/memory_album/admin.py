from django.contrib import admin
from .models import Recuerdo, Perfil, ImagenInicio

admin.site.register(Recuerdo)
admin.site.register(Perfil)
admin.site.register(ImagenInicio)