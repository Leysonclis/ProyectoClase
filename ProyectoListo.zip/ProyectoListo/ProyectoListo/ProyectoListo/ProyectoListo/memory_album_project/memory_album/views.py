from django.shortcuts import render, redirect, get_object_or_404 
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegisterForm, RecuerdoForm
from .models import Recuerdo, ImagenInicio

def home(request):
    if request.user.is_authenticated:
        recuerdos = Recuerdo.objects.filter(autor=request.user)
        return render(request, 'home.html', {'recuerdos': recuerdos})
    else:
        imagenes_inicio = ImagenInicio.objects.all()[:3]  # Limitar a 3 imágenes
        return render(request, 'home.html', {'imagenes_inicio': imagenes_inicio})
def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

from .forms import UserRegisterForm, RecuerdoForm, CustomAuthenticationForm

def login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

def add_recuerdo(request):
    if request.method == 'POST':
        form = RecuerdoForm(request.POST, request.FILES)
        if form.is_valid():
            recuerdo = form.save(commit=False)
            recuerdo.autor = request.user
            recuerdo.save()
            return redirect('home')
    else:
        form = RecuerdoForm()
    return render(request, 'add_recuerdo.html', {'form': form})
    # Vista para editar un recuerdo
def edit_recuerdo(request, pk):
    recuerdo = get_object_or_404(Recuerdo, pk=pk, autor=request.user)
    if request.method == 'POST':
        form = RecuerdoForm(request.POST, request.FILES, instance=recuerdo)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = RecuerdoForm(instance=recuerdo)
    return render(request, 'edit_recuerdo.html', {'form': form})

# Vista para eliminar un recuerdo
def delete_recuerdo(request, pk):
    recuerdo = get_object_or_404(Recuerdo, pk=pk, autor=request.user)
    if request.method == 'POST':
        recuerdo.delete()
        return redirect('home')
    return render(request, 'delete_recuerdo.html', {'recuerdo': recuerdo})