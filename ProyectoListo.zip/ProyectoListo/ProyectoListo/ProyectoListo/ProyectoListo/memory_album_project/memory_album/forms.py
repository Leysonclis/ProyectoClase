from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Recuerdo
from django.utils.translation import gettext_lazy as _
from django.forms.widgets import ClearableFileInput  # Línea corregida

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(label="Correo Electrónico")
    password1 = forms.CharField(label="Contraseña", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Confirmar Contraseña", widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        labels = {
            'username': 'Nombre de Usuario',
        }

        from django.forms.widgets import ClearableFileInput

class CustomClearableFileInput(ClearableFileInput):
    template_name = 'widgets/custom_clearable_file_input.html'  # Personaliza el template si es necesario

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.clear_checkbox_label = None  # Elimina la etiqueta de "Limpiar"

class RecuerdoForm(forms.ModelForm):
    class Meta:
        model = Recuerdo
        fields = ['encabezado', 'imagen', 'fecha_creacion']
        widgets = {
            'fecha_creacion': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Esto elimina la casilla "Borrar" para el campo imagen
        if self.fields.get('imagen'):
            self.fields['imagen'].widget.clear_checkbox_label = ''
            self.fields['imagen'].widget.template_name = 'django/forms/widgets/clearable_file_input.html'
            self.fields['imagen'].required = False


class CustomAuthenticationForm(AuthenticationForm):
    username = forms.CharField(label="Nombre de Usuario", widget=forms.TextInput(attrs={'autofocus': True}))
    password = forms.CharField(label="Contraseña", widget=forms.PasswordInput)